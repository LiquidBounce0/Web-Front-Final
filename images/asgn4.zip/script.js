const form = document.getElementById('form-info');
const fullName= document.getElementById("full-name")
const phoneNumber = document.getElementById("phone-number")
const email= document.getElementById("email")
const responseMethod= document.getElementById("response-method")
const responseQuestion = document.getElementById("question")
const btn = document.querySelector(".form-submit")

const now = new Date();
const day = now.getDay()
const hours = now.getHours();
const minutes = now.getMinutes();
let date = `${day}:${hours}:${minutes}`;

form.addEventListener("submit", function(e) {
    e.preventDefault();

    validateInputs()
})



const setError = (element, message) => {
    const inputControl = element.parentElement;
    const errorDisplay = inputControl.querySelector('.error');

    errorDisplay.innerText = message;
    inputControl.classList.add('error');
    inputControl.classList.remove('success');
}

const setSuccess = element => {
    const inputControl = element.parentElement;
    const errorDisplay = inputControl.querySelector('.error');

    errorDisplay.innerText = '';
    inputControl.classList.add('success');
    inputControl.classList.remove('error');
}

const validateInputs = () => {
    const fullNameValue = fullName.value;
    const phoneNumberValue = phoneNumber.value;
    const emailValue = email.value;
    const responseMethodValue = responseMethod.value;
    const responseQuestionValue = responseMethod.value;

    let isValid = true;

    if (fullNameValue === "") {
        setError(fullName, 'Full name is required');
        isValid = false;
    } else {
        setSuccess(fullName)
    }

    if (phoneNumberValue === "") {
        setError(phoneNumber, 'Phone number is required');
        isValid = false;
    } else {
        const regex = /[a-zA-Zа-яА-Я]/;
        if (regex.test(phoneNumberValue) === true) {
            setError(phoneNumber, "Incorrect number");
            isValid = false;
        } else  {
            setSuccess(phoneNumber);
        }
    }
    if (emailValue === "") {
        setError(email, 'Email is required');
        isValid = false;
    } else {
        if (emailValue.indexOf("@") !== -1 && emailValue.indexOf(".") !== -1) {
            setSuccess(email);
        } else {
            setError(email, "Incorrect Email");
            isValid = false
        }
    }
    // if (responseMethodValue === "") {
    //     setError(responseMethod, 'Method is required');
    //     isValid = false;
    // } else {
    //     setSuccess(responseMethodValue)
    // }
    //
    // if (responseQuestionValue === "") {
    //     setError(responseQuestion, 'Question is required');
    //     isValid = false;
    // } else {
    //     setSuccess(responseQuestion)
    // }

    if (isValid) {
        renderPopup(fullNameValue, phoneNumberValue, emailValue, date)
        showPopup();
    } else {
        console.log(100)
        document.getElementById("form-submit").style.backgroundColor="red";
    }


}

function renderPopup(fullname, number, email, date) {
    document.getElementById("fullnameInfo").innerText = fullname;
    document.getElementById("phoneInfo").innerText = number;
    document.getElementById("emailInfo").innerText = email;
    document.getElementById("dateInfo").innerText = date;

}

function showPopup() {
    document.getElementById("popup").style.display = "flex";
}

function closePopup() {
    document.getElementById("popup").style.display = "none";
}

const faqs = document.querySelectorAll(".faq-block");  // Selects all elements with class .faq-block
faqs.forEach((faq) => {
    faq.addEventListener("click", () => {
        faq.classList.toggle('active');
    });
});